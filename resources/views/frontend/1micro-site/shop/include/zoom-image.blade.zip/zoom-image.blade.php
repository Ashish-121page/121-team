<div class="modal fade" id="zoomImageModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content rounded shadow-lg border-0 overflow-hidden">
            <div class="modal-body">
                <img src="" alt="">
            </div>
        </div>
    </div>
</div>