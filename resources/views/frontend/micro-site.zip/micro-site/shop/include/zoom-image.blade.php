<div class="modal fade" id="zoomImageModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content rounded border-0 overflow-hidden" style="box-shadow:none;background:none;">
            <div class="modal-body">
                <img src="" alt="zoom-image" id="zoomImageContainer" class="w-100" style="object-fit:contain;height: 500px; max-height: 500px; min-height: 500px;">
            </div>
        </div>
    </div>
</div>