@extends('frontend.layouts.main')
@section('meta_data')
    @php
		$meta_title = 'Shop | '.getSetting('app_name');		
		$meta_description = '' ?? getSetting('seo_meta_description');
		$meta_keywords = '' ?? getSetting('seo_meta_keywords');
		$meta_motto = '' ?? getSetting('site_motto');		
		$meta_abstract = '' ?? getSetting('site_motto');		
		$meta_author_name = '' ?? 'GRPL';		
		$meta_author_email = '' ?? 'Hello@121.page';		
		$meta_reply_to = '' ?? getSetting('frontend_footer_email');		
		$meta_img = ' ';		
		$microsite = 1;		
	@endphp
@endsection
@section('content')
<section class="section">
            <div class="text-right">
                <button onclick="getPDF();" class="btn btn-primary" style="position: relative; right: 5rem; top: 2rem;"><i class="fa fa-download"></i> Save as PDF</button>
            </div>
            <div class="container mt-5 canvas_div_pdf">
                @if($cust_details['customer_name'] != '' || $proposal->proposal_note != null)
                    <div class="d-flex">
                        <div >
                            <img src="{{ asset($proposal->client_logo) }}" alt="Client Logo" style="height: 100px;">
                        </div>
                        <div class="ms-3">
                            <h4>{{ $cust_details['customer_name'] }}</h4>
                            <p>{{ nl2br($proposal->proposal_note )?? '' }}</p>
                        </div>
                    </div>
                @endif
                <div class="row">
                    @if($products->count() > 0)
                                @foreach ($products as $key => $product)
                                @php
                                    $user_shop = App\Models\UserShop::where('user_id',auth()->id())->first();
                                    // $usi = productExistInUserShop($product->id,auth()->id(),$user_shop->id);
                                @endphp
                                    <div class="col-lg-3 col-md-4 col-12 mt-4 pt-2">
                                        <div class="card shop-list border-0 position-relative">
                                            <div class="shop-image position-relative overflow-hidden rounded text-center">
                                                <a href="{{ inject_subdomain('shop/'.$product->id,$slug) }}">
                                                    @if( getShopProductImage($product->id,'single') != null)
                                                        <img src="{{ asset(getShopProductImage($product->id)->path ?? asset('frontend/assets/img/placeholder.png')) }}" alt="" class="" style="height:185px;">
                                                    @else
                                                        <img src="{{ asset('backend/default/placeholder.jpg')  }}" class="img-fluid rounded" style="height:185px;">
                                                    @endif
                                                </a> 
                                            </div>
                                            <div class="card-body content pt-4 p-2">
                                                <a href="{{ inject_subdomain('shop/'.$product->id,$slug) }}" class="text-dark product-name h6">{{ $product->title }}</a>
                                                <div style="width:100%">
                                                    <span></span><small>{{ fetchFirst('App\Models\Category',$product->sub_category_id,'name') }} </small>
                                                </div>
                                                <p class="mb-0"><b>Brand:</b><span>{{ $product->brand->name ?? '--' }}</span></p>
                                                <div style="wdith:100%">
                                                    <span>Color </span><small>{{ $product->color ?? '' }} @if($product->size) , @endif <span>Size</span> {{ $product->size ?? ''}}</small>
                                                </div>
                                                @if($product->user_id == auth()->id())
                                                    <span>Model Code :#{{ $product->model_code }}</span>
                                                @else 
                                                    <span>Ref ID :#{{ isset($usi) ? $usi->id : '' }}</span>
                                                @endif   
                                                <div class="d-flex justify-content-between mt-1">
                                                    @php
                                                        $price = getProductProposalPriceByProposalId($proposal->id,$product->id) ?? $product->price;
                                                    @endphp
                                                    @if($proposal->enable_price_range == 1)
                                                        <h6 class="text-dark small fst-italic mb-0 mt-1">
                                                        {{ format_price(($price)-($price*10/100)) }} - {{ format_price(($price)+ ($price*10/100)) }}</h6>
                                                    @else
                                                        <h6 class="text-dark small fst-italic mb-0 mt-1">
                                                        {{ format_price($price) }}</h6>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    @if(++$key%16==0)
                                        <div class="col-12 pdf-margin d-none" style="margin-bottom: 250px">

                                        </div>
                                    @endif
                                @endforeach
                            {{-- </div> --}}
                        {{-- </div><!--end col--> --}}
                    @else
                         <div class="col-lg-6 mx-auto text-center mt-3">
                                <div class="card">
                                    <div class="card-body">
                                        
                                        <i class="fa text-primary fa-lg fa-shopping-cart">
                                        </i>
                                        <p class="mt-4">No Products added yet!</p>
                                    </div>
                                </div>
                            </div>
                    @endif
                </div><!--end row-->
            </div><!--end container-->
        </section>
@endsection
@section('InlineScript')
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.3/jspdf.min.js"></script>
<script src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>
<script>
    function getPDF(){

        if($('.pdf-margin').hasClass('d-none')){
            $('.pdf-margin').removeClass('d-none');
        }else{
            $('.pdf-margin').addClass('d-none');
        }

        var HTML_Width = $(".canvas_div_pdf").width();
        var HTML_Height = $(".canvas_div_pdf").height();
        var top_left_margin = 15;
        var PDF_Width = HTML_Width+(top_left_margin*2);
        var PDF_Height = (PDF_Width*1.5)+(top_left_margin*2);
        var canvas_image_width = HTML_Width;
        var canvas_image_height = HTML_Height;

        var totalPDFPages = Math.ceil(HTML_Height/PDF_Height)-1;


        html2canvas($(".canvas_div_pdf")[0],{allowTaint:true}).then(function(canvas) {
            canvas.getContext('2d');
            
            console.log(canvas.height+"  "+canvas.width);
            
            
            var imgData = canvas.toDataURL("image/jpeg", 1.0);
            var pdf = new jsPDF('p', 'pt',  [PDF_Width, PDF_Height]);
            pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin,canvas_image_width,canvas_image_height);
            
            
            for (var i = 1; i <= totalPDFPages; i++) { 
                pdf.addPage(PDF_Width, PDF_Height);
                pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height*i)+(top_left_margin*4),canvas_image_width,canvas_image_height);
            }
            
            pdf.save("{{Illuminate\Support\Str::slug($proposal_slug) }}.pdf");

            setTimeout(() => {
                $('.pdf-margin').addClass('d-none');
            }, 1000);
        });

    };
</script>
@endsection