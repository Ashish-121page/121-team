
@extends('frontend.layouts.main')
@section('meta_data')
    @php
        $categoryName = fetchFirst('App\Models\Category',request()->get('category_id'),'name') ?? 'All';
		$meta_title = $user_shop->name .' - '.$categoryName  ?? '' .' | '.getSetting('app_name');		
		$meta_description = $user_shop->description ?? getSetting('seo_meta_description');
		$meta_keywords = '' ?? getSetting('seo_meta_keywords');
		$meta_motto = '' ?? getSetting('site_motto');		
		$meta_abstract = '' ?? getSetting('site_motto');		
		$meta_author_name = '' ?? 'GRPL';		
		$meta_author_email = '' ?? 'Hello@121.page';		
		$meta_reply_to = '' ?? getSetting('frontend_footer_email');		
		$meta_img = ' ';		
		$microsite = 1;		
	@endphp
@endsection
@section('content')
<style>

#selector select option {
 color: #333;        
  position: relative;  
  top: 5px;
}

/*==================================================
remove the original arrow in select option dropdown
==================================================*/

    #selector {
    margin: 5px 10%;
    width: 100%;
    }
    
    @media(max-width: 760px){
        #selector {
        margin: auto;
        }
        .filterMobile{
            display: block;
        }
    }
    @media(min-width: 760px){
        .filterMobile{
            display: none;
        }
    }
    .select_box {
    -webkit-appearance: none;
    -moz-appearance: none;
    -o-appearance:none;
    appearance:none;
    }

    .select_box.input-lg {
    height: 50px !important;
    line-height:25px !important;
    }

    .select_box + i.fa {
    float: right;
    margin-top: -32px;
    margin-right: 9px;
    pointer-events: none;
    background-color: #FFF;
    padding-right: 5px;
    }
    .custom-scrollbar{
        max-height: 120px;
        overflow-y: auto;
    }
</style>
<section class="section">
    <div class="container mt-3">
        <div class="row">
                <div class="col-lg-3 col-md-4 col-12">
                    <div class="text-right pl-3 filterMobile" style="margin-top: 10%;">
                        <i title="filter" class="uil uil-bars up_arrow show_mobile_filter" style="    font-size: 23px;"></i>
                        <i class="uil uil-times down_arrow close_mobile_filter" style="    font-size: 23px;"></i>
                    </div>
                    <div class="card border-0 sidebar sticky-bar">
                        <form form role="search" method="GET" id="" class="card-body filter-body p-0 applyFilter d-none d-md-block mobile_filter">
                            <input type="hidden" name="sort" value="" class="sortValue">
                            <h5 class="widget-title pt-3 pl-15" style="display: inline-block;">Filters
                            </h5>
                            <div class="widget px-2">
                                <div>
                                    <div class="input-group mb-3 border rounded">
                                        <input type="text" id="title" value="{{ request()->get('title') }}" name="title" class="form-control border-0" placeholder="Search Product Name...">
                                        <button type="submit" class="input-group-text bg-white border-0" id="searchsubmit"><i class="uil uil-search"></i></button>
                                    </div>
                                </div>
                            </div> 
                            <!-- SEARCH -->

                            <!-- Categories -->
                            <div class="widget bt-1 pt-3 pl-15">
                                <h6 class="widget-title">Categories</h6>
                                <ul class="list-unstyled mt-2 mb-0 custom-scrollbar">
                                    <li>
                                        <h5 class="form-check">
                                            <input class="form-check-input" type="radio" @if(!request()->has('category_id') ||request()->get('category_id') == null ) checked @endif  value="" id="categoryAll" name="category_id">
                                            <label for="categoryAll" class="form-check-label fltr-lbl">
                                                All</label>
                                        </h5>
                                    </li>
                                    @if(!empty($categories))
                                        @foreach ($categories as $item)
                                            @php
                                            $sub_category = App\Models\Category::whereId(request()->get('sub_category_id'))->first();
                                            @endphp
                                            <li>
                                                <h5 class="form-check">
                                                    <input class="form-check-input filterCategory" type="radio" value="{{ $item->id }}" id="category{{ $item->id }}" name="category_id" @if((request()->has('category_id') && request()->get('category_id') ==  $item->id )) checked @endif>
                                                    <label for="category{{ $item->id }}" class="form-check-label fltr-lbl   ">
                                                        {{$item->name}}</label>
                                                </h5>
                                            </li>
                                            @if(request()->has('category_id') && request()->get('category_id') ==  $item->id )
                                                @php
                                                    $subcategories = getProductSubCategoryByShop($slug, $item->id, 0);
                                                @endphp 
                                                <div style="padding-left: 25px">
                                                    <ul class="list-unstyled custom-scrollbar">
                                                        @foreach ($subcategories as $subcategorie)
                                                        
                                                        <li>
                                                            <h6 class="form-check">
                                                                <input class="form-check-input filterSubCategory" type="radio" value="{{ $subcategorie->id }}" id="category{{ $subcategorie->id }}" name="sub_category_id" @if(request()->has('sub_category_id') && request()->get('sub_category_id') ==  $subcategorie->id) checked @endif>
                                                                <label for="category{{ $subcategorie->id }}" class="form-check-label fltr-lbl">
                                                                    {{$subcategorie->name}}</label>
                                                            </h6>
                                                        </li>
                                                        @endforeach
                                                    </ul>
                                                </div>
                                            @endif    
                                        @endforeach
                                    @endif
                                </ul>

                                @if(isset($brands) && $brands->count() >= 1)
                                    <h6 class="widget-title mt-2">Brands</h6>
                                    <ul class="list-unstyled mt-2 mb-0 custom-scrollbar">
                                        @foreach ($brands as $brand)
                                            <li>
                                                <h5 class="form-check">
                                                    <input class="form-check-input" type="radio" value="{{ $brand->id }}" id="brandID" name="brand" @if(request()->has('brand') && request()->get('brand') == $brand->id) checked @endif>
                                                    <label for="brandID" class="form-check-label fltr-lbl ">
                                                        {{ $brand->name }}
                                                    </label>
                                                </h5>
                                            </li>
                                        @endforeach
                                    </ul>
                                @endif  
                                    <h6 class="widget-title mt-2">Price</h6>
                                    <div class="mx-2 d-flex">
                                        <input  style="width: 75px;height: 35px;" @if(request()->has('from') && request()->get('from') != null) value="{{ request()->get('from') }}" @endif type="text" name="from" class="form-control" placeholder=" ₹ Min">
                                        <input style="width: 75px;height: 35px;" @if(request()->has('to') && request()->get('to') != null) value="{{ request()->get('to') }}" @endif type="text" name="to" class="form-control ms-2" placeholder="₹ Max">
                                        <button class="price_go_btn ms-2" type="submit">GO</button>
                                    </div>
                                @if(isset($colors) && $colors->count() >= 0)
                                    <h6 class="widget-title mt-2">Color</h6>
                                    <ul class="list-unstyled mt-2 mb-0 custom-scrollbar" style="height: 60px;">
                                        @foreach ($colors as $color)
                                            @if($color != '' || $color != null)
                                            <li>
                                                <h5 class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="{{ $color }}" id="colorID{{ $color }}"  name="color[]"
                                                    @if(request()->has('color'))  
                                                        @if(isset($color) && in_array($color,request()->get('color')))
                                                            checked
                                                        @endif
                                                    @endif >
                                                    <label for="colorID{{ $color }}" class="form-check-label fltr-lbl ">
                                                        {{ $color }}
                                                    </label>
                                                </h5>
                                            </li>
                                            @endif
                                        @endforeach
                                    </ul>
                                @endif
                                @if(isset($sizes) && $sizes->count() >= 0)
                                    <h6 class="widget-title mt-2">Size</h6>
                                    <ul class="list-unstyled mt-2 mb-0 custom-scrollbar" style="height: 60px;">
                                        @foreach ($sizes as $size)
                                            @if($size != '' || $size != null)
                                            <li>
                                                <h5 class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="{{ $size }}" id="sizeID{{ $size }}" name="size[]"  
                                                    @if(request()->has('size'))  
                                                        @if(isset($size) && in_array($size,request()->get('size')))
                                                            checked
                                                        @endif
                                                    @endif >
                                                    <label for="sizeID{{ $size }}" class="form-check-label fltr-lbl ">
                                                        {{ $size}}
                                                    </label>
                                                </h5>
                                            </li>
                                            @endif
                                        @endforeach
                                    </ul>
                                @endif
                            </div>
                            <button type="submit" class="btn mt-2 d-block btn-primary w-100" id="filterBtn">Filter</button>
                            <button type="submit" class="btn mt-2 d-block btn-primary w-100" >
                                <a class="text-white" href="{{route('pages.shop-index')}}" id="resetButton">Reset</a>
                            </button>
                        </form>
                    </div>
                </div><!--end col-->
                
                <div class="col-lg-9 col-md-8 col-12 pt-2 mt-sm-0 pt-sm-0">
                    <div class="row align-items-center">
                        <div class="col-lg-8 col-md-7">
                            <div class="section-title">
                                <h5 class="mb-0">Showing {{ $items->firstItem() }} to {{ $items->lastItem() }} of {{ $items->total() }} Result</h5>
                            </div>
                        </div><!--end col-->

                        <div class="col-lg-4 col-md-5 mt-sm-0 pt-2 pt-sm-0">
                            <div class="container" id="selector">
                                <select class="form-control input-lg select_box" id="productSort" name="sort">
                                    <option aria-readonly="true">Sort by<i class="fa fa-angle-down"></i>
                                    </option>
                                    <option @if(request()->get('sort') == 1) selected @endif value="1">Sort by latest</option>
                                    <option @if(request()->get('sort') == 2) selected @endif value="2">Sort by price: low to high</option>
                                    <option @if(request()->get('sort') == 3) selected @endif value="3">Sort by price: high to low</option>
                                </select>
                                <i class="fa fa-chevron-down"></i>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        @forelse ($items as $user_shop_item)
                        
                        @php
                            $product = getProductDataById($user_shop_item->product_id);
                            $image_ids = $user_shop_item->images != null ? explode(',',$user_shop_item->images) : [];
                            $price =  $user_shop_item->price ?? 0;
                            if($group_id && $group_id != 0){
                                $price =  getPriceByGroupIdProductId($group_id,$product->id,$price);
                            }
                        @endphp
                       {{-- @dd($product); --}}
                        <div class="col-lg-3 col-md-4 col-12 pt-2">
                                <div class="card shop-list border-0 position-relative">
                                    <div class="shop-image position-relative overflow-hidden rounded shadow">
                                        @php
                                            $productId= \Crypt::encrypt($product->id);
                                        @endphp
                                        <a target="_blank" href="{{ route('pages.shop-show',$productId)."?pg=".request()->get('pg') }}">
                                            <img src="{{ asset(getMediaByIds($image_ids)->path ?? asset('frontend/assets/img/placeholder.png')) }}" class="img-fluid " style="height: 150px;width: 100%;object-fit: contain;" alt="">
                                        </a>
                                        <ul class="list-unstyled shop-icons">
                                            <li class="mt-1"><a href="{{ route('pages.shop-show',$productId)."?pg=".request()->get('pg') }}" class="btn btn-icon btn-pills btn-soft-primary"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye icons"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg></a></li>
                                            @if($price != 0)
                                            <form action="{{ route('pages.add-cart')}}" method="POST">
                                                @csrf
                                                <input type="hidden" name="unit_price" value="{{ $price }}">
                                                <input type="hidden" name="qty" value="1">
                                                <input type="hidden" name="product_id" value="{{ $product->id }}">
                                                {{-- <li class="mt-2">
                                                    <button type="submit" class="btn btn-icon btn-pills btn-soft-warning">
                                                        <x-icon name="shopping-cart" class="feather feather-shopping-cart icons" />
                                                    </button>
                                                </li> --}}
                                            </form>
                                            @endif
                                        </ul>
                                    </div>
                                    <div class="card-body content pt-4 p-2 text-center">
                                        <h6 class="text-dark small fst-italic mb-0 mt-1">
                                            {{-- @dd($price); --}}
                                            @if($price)
                                                {{ format_price($price) }}
                                            @else
                                                <span>{{ format_price(0) }}</span>
                                            @endif
                                        </h6>
                                        <a target="_blank" href="{{ route('pages.shop-show',$productId)."?pg=".request()->get('pg') }}" class="text-dark product-name h6">{{ \Str::limit($product->title,30) }}</a> 
                                        <div>
                                            {{-- <span>{{ $product->color }}</span> @if(isset($product->size)) , @endif<span>{{ $product->size }}</span> --}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @empty
                            <div class="col-lg-12 mx-auto text-center mt-3">
                                <div class="card">
                                    <div class="card-body">
                                        <i class="fa text-primary fa-lg fa-shopping-cart">
                                        </i>
                                        <p>Alter filter conditions, no products matching the search criteria.</p>
                                    </div>
                                </div>
                            </div>
                            @endforelse
                        </div>
                    <div class="d-flex justify-content-center">
                        {{ $items->appends(request()->query())->links() }} 
                    </div>
                </div>

            <!--end col-->
        </div><!--end row-->
    </div><!--end container-->
</section>
@endsection


@section('InlineScript')
<script>
    var active_category = "{{request()->get('category_id') }}";
    var active_sub_category = "{{request()->get('sub_category_id') }}";
        $('.down_arrow').addClass('d-none');
       
        $('.filterCategory').on('click', function(){
            if(active_category == $(this).val()){
                $(this).val(null);
                $(document).find('.filterSubCategory').val(null);
            }else{
                $(document).find('.filterSubCategory').val(null);
            }
            $('.applyFilter').submit();
       });

     

        $('.filterSubCategory').on('click', function(){ 
            if(active_sub_category == $(this).val()){
                $(this).val(null);
            }
            $('.applyFilter').submit();
       });

       $('#productSort').on('change', function(){
            var value = $(this).val();
            $('.sortValue').val(value);
            $('.applyFilter').submit();
       });
       $('.show_mobile_filter').on('click',function(){
            $('.up_arrow').addClass('d-none');
            $('.down_arrow').removeClass('d-none');
            $('.mobile_filter').removeClass('d-none');
       });
       $('.close_mobile_filter').on('click',function(){
            $('.up_arrow').removeClass('d-none');
            $('.down_arrow').addClass('d-none');
            $('.mobile_filter').addClass('d-none');
       });

       $('#categoryAll').click(function(){
           url = "{{route('pages.shop-index')}}";
           window.location.href = url;
       });
    </script>
@endsection