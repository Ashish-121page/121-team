@extends('backend.layouts.main') 
@section('title', 'Dashboard')
@section('content')
<div class="text-center">
    <img src="{{ asset('frontend/assets/img/Welcome-cuate.png') }}" width="40%" alt="">
</div>
@endsection